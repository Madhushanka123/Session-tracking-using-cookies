
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ClientInfo extends HttpServlet {

    //Developer:Madhushanka Chithrananda
    //BSC-UGC-SE-16.1-002
    int count = 0;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {

            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ClientInfo</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ClientInfo at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        PrintWriter out = response.getWriter();

        if (count == 0) {

            String first_Name = request.getParameter("fname");
            String last_Name = request.getParameter("lname");
            String _email = request.getParameter("email");
            //Check firstname field is empty or null
            if (first_Name != null && !first_Name.isEmpty()) {
                first_Name = request.getParameter("fname");
            } else {
                first_Name = "Unknown";
            }
            //Check lastname field is empty or null
            if (last_Name != null && !last_Name.isEmpty()) {
                last_Name = request.getParameter("lname");
            } else {
                last_Name = "Unknown";
            }
            //Check email field is empty or null
            if (_email != null && !_email.isEmpty()) {
                _email = request.getParameter("email");
            } else {
                _email = "Unknown";
            }

            //create cookies     
            Cookie firstName = new Cookie("first_name", first_Name);
            Cookie lastName = new Cookie("last_name", last_Name);
            Cookie email = new Cookie("email", _email);

            // Set expiry time by 5minutes
            firstName.setMaxAge(60 * 5);
            lastName.setMaxAge(60 * 5);
            email.setMaxAge(60 * 5);

            //Add cookies to response header
            response.addCookie(firstName);
            response.addCookie(lastName);
            response.addCookie(email);
            out.println("first_name :" + first_Name);
            out.println("last_name :" + last_Name);
            out.println("email :" + _email);
            count++;

        } //For repeat visitor
        else {
            Cookie[] cookies = request.getCookies();//get all the created cookies and creat a cookie array
            for (Cookie cookie : cookies) {
                out.println(cookie.getName() + " : ");//display cookie name
                out.println(cookie.getValue());//display cookie value
                count++;
            }
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
